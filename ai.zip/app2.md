# Application B Implementation - LL Demo IG v0.1.0

* [**Table of Contents**](toc.md)
* **Application B Implementation**

## Application B Implementation

Placeholder content to explain app 2 integration.

